package br.com.fuctura.indo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndoApplicationTests {

	@Test
	void contextLoads() {
	}

}
