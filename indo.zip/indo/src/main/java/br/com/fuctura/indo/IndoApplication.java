package br.com.fuctura.indo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndoApplication.class, args);
	}

}
